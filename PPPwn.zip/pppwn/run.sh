#!/bin/sh

if ! pgrep pppwn > /dev/null; then
    if [ -f /root/pw.conf ];then
        source /root/pw.conf
        if /etc/init.d/pppoe-server status | grep -q "running"; then
            /etc/init.d/pppoe-server stop
            sleep 1
        fi
        ip link set $interface down
        sleep 3
        ip link set $interface up
        echo "heartbeat" > /sys/class/leds/yellow:power/trigger
        result=$(pppwn --interface "$interface" --fw "$version" --stage1 "$stage1" --stage2 "$stage2" --timeout $timeout --auto-retry)
        if [[ "$result" == *"\[\+\] Done\!"* ]]; then
            if /etc/init.d/pppoe-server status | grep -q "inactive"; then
                /etc/init.d/pppoe-server start
		poweroff
            fi
            echo "{\"output\":\"Exploit success\",\"pppwned\":true}"
            exit 0
        else
            if /etc/init.d/pppoe-server status | grep -q "inactive"; then
                /etc/init.d/pppoe-server start
            fi
            echo "{\"output\":\"Exploit interrupted\",\"pppwned\":false}"
            exit 1
        fi

    fi

else
    echo "{\"output\":\"PPPwn is running\",\"running\":true}"
    exit 0
fi